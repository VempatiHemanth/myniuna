﻿using System;
using System.IO.MemoryMappedFiles;
using System.Runtime.InteropServices;
using System.Threading;

namespace SharedMemoryWin
{

	// Example structure for data exchange
	internal struct DataExchange1
	{
		internal Double i1;
		internal Double i2;
	}
	internal struct DataExchange                          //CNC->HMI
	{
		internal double X_POS;
		
		internal double W_POS;
		internal double X_VEL;
		internal double Z_POS;
		internal double Z_VEL;

		internal double W_VEL;
		internal double U_POS;
		internal double U_VEL;
		internal double S_VEL;
		internal double S_Iq;                        //q方向电流
		internal double A1_POS;
		internal double A1_VEL;
		internal double A2_POS;
		internal double A2_VEL;



	}
	class Program
	{
		static void Main(string[] args)
		{
			DataExchange dataExchangeRead;
			DataExchange1 dataExchangeWrite;
			dataExchangeWrite.i1 = 0;
			dataExchangeWrite.i2 = 0;
			dataExchangeRead.X_POS = 0;
			
			dataExchangeRead.W_POS = 0;
			dataExchangeRead.X_VEL = 0;
			dataExchangeRead.Z_POS = 0;
			dataExchangeRead.Z_VEL = 0;

			dataExchangeRead.W_VEL = 0;
			dataExchangeRead.U_POS = 0;
			dataExchangeRead.U_VEL = 0;
			dataExchangeRead.S_Iq = 0;
			dataExchangeRead.S_VEL = 0;
			dataExchangeRead.A1_POS = 0;
			dataExchangeRead.A1_VEL = 0;
			dataExchangeRead.A2_POS = 0;
			dataExchangeRead.A2_VEL = 0;

			Console.Out.WriteLine("Press 'q' to quit");

			int dataSIze = Marshal.SizeOf(typeof(DataExchange));

			// Open a mapped file with read access and one with write access. 
			
			using (var mmfRead = MemoryMappedFile.CreateOrOpen("file", 2000))

			using (var mmfWrite = MemoryMappedFile.CreateOrOpen("file", 2000))
			
			{
				bool quit = false;
				while (!quit)
				{
					using (var accessorRead = mmfRead.CreateViewAccessor(0, dataSIze, MemoryMappedFileAccess.Read))
					using (var accessorWrite = mmfWrite.CreateViewAccessor(0, dataSIze, MemoryMappedFileAccess.Write))
					{
						// Read the structure
						try
						{
							accessorRead.Read(0, out dataExchangeRead.X_POS);//read from position 0
							//accessorRead.Read(1, out dataExchangeRead.W_POS);//read from position 1
						}
						catch (Exception err)
						{
							Console.Write(err.ToString());
						}
						// Write the structure
						//accessorWrite.Write(10, ref dataExchangeWrite.i1);//write to position 10
						accessorWrite.Write(11, ref dataExchangeWrite.i2);//write to position 11

						Random rand = new Random();// create instance of generating random variable
						//dataExchangeWrite.i1 = rand.NextDouble();//Generate random Double Value i1
						dataExchangeWrite.i2 = rand.NextDouble();//Generate random Double Value i2


						// Display the values
						Console.Out.Write("Read i1: {0:0.####} i2: {1:0.####}       \r",
											dataExchangeRead.X_POS,
											dataExchangeWrite.i2);

						// Wait a second
						Thread.Sleep(2000);

						// Check quit condition
						if (Console.KeyAvailable)
							if (Console.ReadKey().KeyChar == 'q')
								quit = true;
					}
				}
			}
		}
	}
}

